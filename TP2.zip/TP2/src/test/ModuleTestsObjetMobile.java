package test;
/**
 * Module de tests unitaires pour les méthodes de la classe ObjetMobile
 * 
 * @author Catherine Sauvé
 * @author Xuan Truc Doan
 * @version Hiver 2021
 */

//import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.*;

//import modele.physique.Point2D;
//import modele.reseau.Cellulaire;

public class ModuleTestsObjetMobile {

    //Variables des points pour tester les méthodes de la classe Point2D
   // private double directionReference;
   // private double vitesseReference;
   // private double deviationStandardReference;
   // private Point2D resultatAttendu = new Point2D();

   // private Cellulaire cellulaireTest = new Cellulaire();
   

    @BeforeAll
    static void initAll() {
        System.out.println("TESTS OBJET MOBILE"); 
       
    }

    @BeforeEach
    void setUp() { 
        
        //double directionReference = 5;
        //double vitesseReference = 10.0;
	    //double deviationStandardReference = 0.05;
        
    }

    @Test
    void testCase() {

       

        
    }
      
    

    @AfterEach
    void tearDown() {
    }

    @AfterAll
    static void tearDownAll() {
    }
}

