package test;

/**
 * Module de tests unitaires pour les méthodes de la classe Point2D
 * 
 * @author Catherine Sauvé
 * @author Xuan Truc Doan
 * @version Hiver 2021
 */

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.*;

import modele.physique.Point2D;

public class ModuleTestsPoint2D  {
    
    //Variables des points pour tester les méthodes de la classe Point2D
    private Point2D pointReference;
    private Point2D pointTest;
    private Point2D pointAttendu;
    private  double resultatAttendu;

    @BeforeAll
    static void initAll() {
        System.out.println("TESTS POINT2D"); 
       
    }

    @BeforeEach
    void setUp() throws Exception{ 

        pointReference = new Point2D(5,10);
        pointTest = new Point2D(20, 50);

        //Contient le Point2D attendu suite à un calcul par une méthode
        pointAttendu = new Point2D();

        //Contient le résultat attendu suite à un calcul par une méthode
        resultatAttendu = 0;
        
    }

    @Test
    @DisplayName("Test calcul de la distance entre deux Point2D")
    void testCalculDistance() {

        resultatAttendu = Math.sqrt(Math.pow(pointTest.getX() - 
                                    pointReference.getX(),2) + 
                                    Math.pow(pointTest.getY() - 
                                    pointReference.getY(),2));

        //Comparaison pour le test  
        assertEquals(resultatAttendu, pointReference.distance(pointTest));
    }

    @Test
    @DisplayName("Test calcul de la pente entre deux Point2D")
    void testCalculPente(){

        resultatAttendu = (pointTest.getY() - pointReference.getY()) / 
                          (pointTest.getX() - pointReference.getX());

        //Comparaison pour le test
        assertEquals(resultatAttendu, pointReference.pente(pointTest));
    } 

    @Test
    @DisplayName("Test calcul du point milieu entre deux Point2D")
    void testPointMilieu(){

        pointAttendu.setX(Math.abs((pointReference.getX()-pointTest.getX())/2)); 
        pointAttendu.setY(Math.abs((pointReference.getY()-pointTest.getY())/2));

        //Comparaison pour le test
        assertEquals(pointAttendu.toString(), 
                     pointReference.milieu(pointTest).toString());
                     
    }

    @AfterEach
    void tearDown() {

        //On réinitialise les variables
        pointAttendu = new Point2D();

        resultatAttendu = 0;
    }

    @AfterAll
    static void tearDownAll() {

    }

    
}
