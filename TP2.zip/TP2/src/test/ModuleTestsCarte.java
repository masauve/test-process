package test;
/**
 * Module de tests unitaires pour les méthodes de la classe Carte
 * 
 * @author Catherine Sauvé
 * @author Xuan Truc Doan
 * @version Hiver 2021
 */

//import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.*;

import modele.physique.Carte;

public class ModuleTestsCarte {
    
    @BeforeAll
    static void initAll() {

       System.out.println("TESTS CARTE");
    }

    @BeforeEach
    void setUp() { 
      
    }

    @Test
    void TestCase() {    

        // Point Aléatoire
        Carte.genererPositionAleatoire();
        
    }

    @AfterEach
    void tearDown() {

        System.out.println("SUCCÈS");
    }

    @AfterAll
    static void tearDownAll() {
        System.out.println("-- Fin Tests Carte --");
    }

}
