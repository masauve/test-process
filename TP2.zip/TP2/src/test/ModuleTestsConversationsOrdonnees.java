package test;
/**
 * Module de tests unitaires pour les méthodes de la classe 
 * ConversationsOrdonnees
 * 
 * @author Catherine Sauvé
 * @author Xuan Truc Doan
 * @version Hiver 2021
 */

//import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.*;

public class ModuleTestsConversationsOrdonnees {

    //Variables des points pour tester les méthodes de la classe Point2D
    private Object donneeReference;
    private Object donneeTest;
    private Object donneeAttendu;
    private  double resultatAttendu;

    @BeforeAll
    static void initAll() {
        System.out.println("TESTS CONVERSATIONS ORDONNÉES"); 
       
    }

    @BeforeEach
    void setUp() { 
        
        
    }

    @Test
    void testCase() {
      
    }

    @AfterEach
    void tearDown() {
    }

    @AfterAll
    static void tearDownAll() {
    }
}
