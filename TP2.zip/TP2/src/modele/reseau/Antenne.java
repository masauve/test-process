package modele.reseau;
import java.util.ArrayList;

/**
 * Classe.....
 * 
 * On retrouve les méthodes :
 * - distance() 
 * - toString() 
 * 
 * 
 * @author Catherine Sauvé
 * @version Hiver 2021
 */
import modele.communication.Message;
import modele.physique.ObjetPhysique;
import modele.physique.Point2D;

public class Antenne extends ObjetPhysique implements UniteCellulaire {


    // On obtient la seule instance du gestionnaire de réseau.
	GestionnaireReseau instance = GestionnaireReseau.getInstance();

    ArrayList<Cellulaire> cellulaires = new ArrayList<Cellulaire>();

    /**
     * Constructeur par défaut
     */
    public Antenne() {

    }
    
    /**
     * Constructeur par paramètre qui reçoit une position.
     * @param position
     */
    public Antenne(Point2D position) {

        this.position = position;
    }

    /**
     * Méthode exposant la méthode distance équivalente définie dans Position.
     * @param position à considérer
     * @return la racine carrée de la somme des différences en x et en y au carré
     *
     */
    public double distance (Point2D position){
        
        return 0;
    }

     /**
     * Retourne la position actuelle sous forme de chaîne de caractères "(x,y)"
     */
    public String toString(){
        return "(" + position.getX() + "," + position.getY() + ")";
    }

    //De la classe abstaire ObjetPhysique
    @Override
    public Point2D getPosition() {

        return position;
    }



    @Override
    public int appeler(String numAppele, String numAppelant, Antenne antenneConnecte) {
        
        
        return 0;
    }

    @Override
    public Cellulaire repondre(String numAppele, String numAppelant, int numConnection) {
        
        return null;
    }

    @Override
    public void finAppelLocal(String numAppele, int numConnection) {

    }

    @Override
    public void finAppelDistant(String numAppele, int numConnection) {

    }

    @Override
    public void envoyer(Message message, int numConnection) {

    }

    @Override
    public void recevoir(Message message) {

    }
    
}
