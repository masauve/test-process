package modele.reseau;
/**
 * Interface décrivant le comportement minimum des sous classes représentant une
 * unite Cellulaire
 * 
 * On retrouve les méthodes suivantes : 
 * 
 * - appeler(String numAppele, String numAppelant, Antenne antenneConnecte)
 * - repondre(String numAppele, String numAppelant, int numeroConnexion)
 * - finAppelLocal(String numAppele, int numeroConnexion)
 * - finAppelDistant(String numAppele, int numeroConnexion)
 * - envoyer(Message message, int numeroConnexion)
 * - recevoir(Message message)
 * 
 * @author Catherine Sauvé
 * @author Xuan Truc Doan
 * @version Hiver 2021
 */

import modele.communication.Message;

public interface UniteCellulaire {

    /**
     * Retourne un entier qui indique le numéro de connexion
     * @param numAppele
     * @param numAppelant
     * @param antenneConnecte
     * @return numéro de connexion
     */
    public int appeler(String numAppele, 
                       String numAppelant, Antenne antenneConnecte);
    

    /**
     * Retourne la référence au cellulaire qui répond
     * @param numAppele
     * @param numAppelant
     * @param numeroConnexion
     * @return la référence au cellulaire qui répond
     */
    public Cellulaire repondre(String numAppele, 
                              String numAppelant, int numeroConnexion);

    /**
     * 
     * @param numAppele
     * @param numeroConnexion
     */
    public void finAppelLocal(String numAppele, int numeroConnexion);

    /**
     * 
     * @param numAppele
     * @param numeroConnexion
     */
    public void finAppelDistant(String numAppele, int numeroConnexion);
   
    /**
     * 
     * @param message
     * @param numeroConnexion
     */
    public void envoyer(Message message, int numeroConnexion);

    /**
     * 
     * @param message
     */
    public void recevoir(Message message);

    
}
