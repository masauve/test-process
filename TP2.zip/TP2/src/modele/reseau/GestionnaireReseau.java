package modele.reseau;

/**
 * Le gestionnaire réseau est responsable de gérer les connexions cellulaires 
 * et de relayer  les appels, messages et fin d'appel.
 * 
 * Dans le cadre de la simulation, c'est également le gestionnaire réseau qui 
 * instancie Antennes et Cellulaire et qui gère l'exécution par tour 
 * des cellulaires.
 * 
 * Il ne peut y avoir qu'un gestionnaire réseau dans le projet (singleton).
 * 
 * @author Fred Simard
 * @version Hiver 2021
 * @révision et commentaires Pierre Bélisle
 * @author Catherine Sauvé
 * 
 */

import java.util.ArrayList;

import modele.gestionnaires.GestionnaireScenario;
import modele.physique.Carte;
import observer.MonObservable;


// Un objet de cette classe est observable.
public class GestionnaireReseau extends MonObservable implements Runnable {

	/*******************************
	 * Constantes
	 *******************************/
	private static final int PERIODE_SIMULATION_MS = 100;
	private static final double VITESSE = 10.0;
	private static final double DEVIATION_STANDARD = 0.05;
	private static final int NB_CELLULAIRES = 30;
	private static final int NB_ANTENNES = 10;
	private static final int CODE_NON_CONNECTE = -1;

	// Mis à faux s'il ne reste plus de messages à envoyer.
	private boolean mondeEnVie = true;

	// On instancie un objet de la classe GestionnaireReseau en privé.
	private static GestionnaireReseau instance = new GestionnaireReseau();

	// Collection de cellulaires
	private ArrayList<Cellulaire> cellulaires = new ArrayList<Cellulaire>();

	// Collection d'antennes
	private ArrayList<Antenne> antennes = new ArrayList<Antenne>();

	// Une liste ordonnée contenant des connexions
	//private ArrayList<Connexion> listeConnexions = new ArrayList<Connexion>();

	/**
	 * Méthode permettant d'obtenir la référence sur le gestionnaire réseau.
	 * 
	 * @return La référence du réseau
	 */
	public static GestionnaireReseau getInstance() {
		return instance;
	}

	/**
	 * Permet d'obtenir la référence sur la collection Cellulaire
	 * 
	 * @return La référence de Cellulaire
	 */
	public ArrayList<Cellulaire> getCellulaires() {
		return cellulaires;
	}

	/**
	 * Permet d'obtenir la référence sur la collection Antenne
	 * 
	 * @return La référence d'Antenne
	 */
	public ArrayList<Antenne> getAntennes() {
		return antennes;
	}

	/**
	 * Permet de mettre fin à la simulation.
	 * 
	 */
	public void finDeSimulation() {

		this.mondeEnVie = false;
	}

	/**
	 * Permet de créer des Antennes et de les ajouter dans la collection
	 * @return
	 */
	public void creeAntennes() {

		for(int i = 0; i < NB_ANTENNES; i++) {

			Antenne nouvelleAntenne = new Antenne(null);			
			antennes.add(nouvelleAntenne);
		}

	}

	/**
	 * Permet de créer des Cellulaires et de les ajouter dans la collection
	 * @return
	 */
	public void creeCellulaires() {

		/**
		 * NOTE: utiliser GestionnaireScenario::obtenirNouveauNumeroStandard(), 
		 * pour obtenir des numéros de téléphones.
		 */


		for (int i = 0; i < NB_CELLULAIRES; i++) {

			Cellulaire nouveauCellulaire = new Cellulaire
						   (GestionnaireScenario::obtenirNouveauNumeroStandard,
						   Carte.genererPositionAleatoire(), 
				 		   VITESSE, 
				 		   DEVIATION_STANDARD);

			cellulaires.add(nouveauCellulaire);
		}


	}

	public int relayerAppel() {
		/*obtient un numéro de connexion unique (à vous de le faire)
		(3) parcourt toutes les Antennes en appelant leur méthode répondre()
		si l’une d’entre elle retourne une référence valide. (5)
		(4) ajoute une nouvelle connexion à la liste ordonnée
		la connexion obtient des références à l’antenne source et l’antenne destination
		retourne le numéro de connexion
		sinon, retourne le CODE_NON_CONNECTE*/

		boolean estConnecte = false;

		int numeroConnexion = 0;

		for(int i = 0; i < antennes.size(); i++) {
			
			antennes.get(i);
		}

		return (estConnecte==true) ? numeroConnexion : CODE_NON_CONNECTE;
	}

	/**
	 * S'exécute en continue pour simuler le système.
	 */
	@Override
	public void run() {
		
		
		creeAntennes();
		creeCellulaires();
		this.avertirLesObservers();

		while(this.mondeEnVie) {	
			
			for(Cellulaire cell : cellulaires) {
				cell.effectuerTour();
			}
			
			this.avertirLesObservers();
			
			
			try {
				Thread.sleep(PERIODE_SIMULATION_MS);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
	}
}
	
