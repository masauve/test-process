package modele.reseau;

/**
 * Classe.....
 * 
 * On retrouve les méthodes :
 * - boolean estConnecte(int numeroConnexion)
 * - equals(Cellulaire numeroCellulaire) 
 * - toString()
 * 
 * 
 * @author Catherine Sauvé
 * @version Hiver 2021
 */

import modele.communication.Message;
import modele.physique.ObjetMobile;
import modele.physique.Point2D;

import java.util.Random;

public class Cellulaire extends ObjetMobile implements UniteCellulaire {

    /*******************************
	 * 	Constantes
	 *******************************/
    private static final int NON_CONNECTE = -1;
    private static final double PROB_APPELER = 0.05;
    private static final double PROB_ENVOI_MSG = 0.2;
    private static final double PROB_DECONNEXION = 0.1;

    private String numeroLocal;
    private int numeroConnexion; 
    private String numeroConnecte;
    private Antenne antenneConnecte; 

    private Random rand = new Random();
   
    // On obtient la seule instance du gestionnaire de réseau.
	GestionnaireReseau instance = GestionnaireReseau.getInstance();             

    /**
     * Constructeur par défaut
     */
    public Cellulaire(){

        // Appel du constructeur par défaut de la classe ObjectMobile
        super();

        numeroLocal = null;
        numeroConnexion = NON_CONNECTE;
        numeroConnecte = null;
        antenneConnecte = null;
    }

    /**
     * Constructeur par paramètres
     * @param numeroLocal
     * @param position
     * @param vitesse
     * @param deviation
     */
    public Cellulaire(String numeroLocal, Point2D position, 
                      double vitesse, double deviationStandard) {
        
        super(position,vitesse,deviationStandard);
        this.numeroLocal = numeroLocal;
    }

    /**************************************************
     * LES ACCESSEURS 
     **************************************************/
    /**
     * Permet d'obtenir le numéro local du cellulaire
     * @return numeroLocal
     */
    public String getCellulaire() {

        return numeroLocal;
    }

    /**
     * Permet d'obtenir le numéro de connexion
     * @return numeroConnexion
     */
    public int getNumeroConnexion() {

        return numeroConnexion;
    }

    @Override
    public Point2D getPosition(){

        return position;
    }

    /***********************************************
     * LES COMPORTEMENTS
     ************************************************/

    /**
     * Permet de savoir si le cellulaire est connecté 
     * @param numeroConnexion
     * @return
     */
    public boolean estConnecte(){

        return (numeroConnexion != NON_CONNECTE) ? false : true;
    }

    /**
     * Permet d'obtenir l’antenne la plus proche à chaque tour 
     */
    public void effectuerTour() {

	}

    /**
     * Compare le numéro du cellulaire au numero local
     * @param numeroCellulaire
     * @return
     */
    public boolean equals(Cellulaire numeroCellulaire){

       return numeroCellulaire.numeroLocal == numeroLocal;
    }

    /**
     * Retourne le numéro local et la position sous la forme d'une chaîne de 
     * caractère.
     */
    public String toString() {

        return "numéro local : " + numeroLocal + "\nposition : " + position;
    }


    @Override
    public int appeler(String numAppele, String numAppelant, 
                                         Antenne antenneConnecte) {
        
        return 0;
    }

    @Override
    public Cellulaire repondre(String numAppele, String numAppelant, 
                                                 int numConnection) {

        return null;
    }

    @Override
    public void finAppelLocal(String numAppele, int numConnection) {
        

    }

    @Override
    public void finAppelDistant(String numAppele, int numConnection) {
       

    }

    @Override
    public void envoyer(Message message, int numConnection) {
        

    }

    @Override
    public void recevoir(Message message) {
       

    }
 
}
