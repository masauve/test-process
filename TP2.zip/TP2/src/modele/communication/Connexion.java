package modele.communication;

/**
 * Classe 
 * 
 * On retrouve les méthodes :
 * - equals(Connexion numConnexion)
 * 
 * @author Catherine Sauvé
 * @author Xuan Truc Doan
 * @version Hiver 2021
 */

import java.util.ArrayList;
import java.util.Collection;

import modele.reseau.Antenne;

public class Connexion {

    /*******************************
	 * 	Constantes
	 *******************************/
    private static final int NB_ANTENNES = 2;

    private int numeroConnexion;
    // Collection d'antennes
	private Collection<Antenne> antennes = new ArrayList<>(NB_ANTENNES);

    /**
     * Constructeur par défaut
     */
    public Connexion(){
    
        numeroConnexion = 0;
    }

    /**
     * Constructeur par paramètres, reçoit un numéro de connexion et 2 antennes
     * @param numeroConnexion
     * @param antenne1
     * @param antenne2
     */
    public Connexion(int numeroConnexion, Antenne antenne1, Antenne antenne2){
        
        this.numeroConnexion = numeroConnexion;
        this.antennes.add(antenne1);
        this.antennes.add(antenne2);
    }

    /**************************************************
     * LES ACCESSEURS 
     **************************************************/
    /**
     * Permet d'obtenir le numéro de connexion
     * @return
     */
    public int numeroConnexion() {

        return numeroConnexion;
    }

    /***********************************************
     * LES COMPORTEMENTS
     ************************************************/
    /**
     * Compare les numéros de connexion
     * @param numConnexion
     * @return
     */
    public boolean equals(Connexion numConnexion) {

        return numConnexion.numeroConnexion == numeroConnexion;
    }

    /**
     * Compare les numéros de la connexion actuelle et d'une connexion reçue en
     * paramètre.
     * 
     * @param numConnexion
     * @return 0 si les numeros sont les mêmes, un entier négatif si la valeur 
     * comparée est inférieure à la valeur reçue en paramètre ou sinon un entier 
     * positif.
     */
    public int comparerNumeroConnexion(String numConnexion) {

        /**
         * Stratégie : On utilise String.compareTo de java pour comparer les 
         * deux numéros.
         */
    
        return this.antennes.toString().compareTo(numConnexion);
    }
}
