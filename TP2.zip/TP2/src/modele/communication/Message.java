package modele.communication;
/**
 * Classe 
 * 
 * 
 * @author Catherine Sauvé
 * @author Xuan Truc Doan
 * @version Hiver 2021
 */
public class Message {

    //On conserve le numéro de destination
    private String numeroDestination;
    private String message;

    /**
     * Constructeur par défaut
     */
    public Message() {
        numeroDestination = null;
        message = null;
    }

    /**
     * Constructeur par paramètres
     * @param numeroDestination
     * @param message
     */
    public Message(String numeroDestination, String message){

        this.numeroDestination = numeroDestination;
        this.message = message;
    }
    
    /**
     * Constructeur par copie d'objet
     * @param message
     */
    public Message(Message message) {
        this(message.numeroDestination, message.message);
    }

    /**************************************************
     * LES ACCESSEURS 
     **************************************************/
    /**
     * Permet d'obtenir le numéro de destination
     * @return numeroDestination
     */
    public String numeroDestination() {

        return numeroDestination;
    }

    /**
     * Permet d'obtenir le message
     * @return
     */
    public String message() {

        return message;
    }

    
}
