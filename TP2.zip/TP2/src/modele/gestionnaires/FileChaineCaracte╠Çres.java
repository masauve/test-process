package modele.gestionnaires;
/**
 * Implémente une file de chaînes de caractères.
 * 
 * On retrouve les méthodes suivantes :
 * - initFile()
 * - defiler()
 * 
 * @author Catherine Sauvé
 * @author Xuan Truc Doan
 * @version Hiver 2021
 */
public class FileChaineCaractères {

    //Taille par défaut de la file (nombre arbitraire)
    public static int TAILLE = 100;

    //la file
	private String[] file;

	//Nombre d'éléments dans la file
    int nbElement;

    //Les indices de début et de fin de la file.
    int debut;
    int fin;

    /**********************************************
     *  CONSTRUCTEURS
     **********************************************/
     /**
     * Constructeur par défaut
     *
     * Il y aura File.TAILLE éléments possibles dans la file.
     */
    public FileChaineCaractères(){
    	
    	file = new String[TAILLE];
    	
    	initFile();
    }

    /**
     * Constructeur par paramètres
     * Construit une file de la taille voulue.
     * 
     * @param taille La taille voulue pour la file.
     */
    public FileChaineCaractères(int taille){

    	file = new String[taille];
    }

    /**********************************************
     *  COMPORTEMENTS
     **********************************************/
    /**
     * Permet d'éviter la répétition du code pour l'initialisation de la file.
     */
	private void initFile() {
         
        debut = 0;
        fin = TAILLE;
        nbElement = 0;
        
        for(int i = 0; i < file.length; i++) {
            file[i] = null;
        }
    }

    /**
     * Retourne la valeur qui est sur le dessus de la file.
     * 
     * @return Le premier élément de la file.
     * @throws Exception si la file est vide
     */
    public String defiler() throws  Exception{

        //élément de la file
    	String element = null;

        //vérifie que la pile n'est pas vide
		if(nbElement == 0) {

            throw new Exception("Impossible de défiler, car la pile est vide.");
        }

		//On récupère le premier élément
		element = file[debut];

        //déplace la tête sur la case suivante de façon circulaire 
		debut = ++debut % file.length;

		//Un élément de moins
		nbElement--;

        return element;
    }
    
}
