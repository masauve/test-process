/** 
 * Sert à montrer
 *           -la mécanique d'appel des constructeurs lors du new
 *           -la définition des observateurs et des mutateurs
 *           -la définition de comportements possibles
 *            d'objets de cette classe
 *
 * @author  Pierre Bélisle
 * @version octobre 2000
 */
package modele.physique;

public class Point2D  {

    //attributs qui correspondent à la coordonnée (x,y) d'un point dans le plan
    //cartésien en 2 dimensions
    protected double x = 0;
    protected double y = 0;

    /**
     * Constructeur par défaut
     */
    public Point2D() {
        x = 0;
        y = 0;
    };
 
    /**
     * Constructeur par paramètres
     * @param x
     * @param y
     */
    public Point2D(double x, double y) {

        this.x = x;
        this.y = y;
    }

    /**
     * constructeur par copie d'objet
     * @param p
     */
    public Point2D(Point2D p) {

        this(p.x, p.y); 
    }
    
    /**************************************************
     * 
     * LES ACCESSEURS 
     * 
     **************************************************/
    /**
     * Permet d'obtenir la coordonnées en x du point
     * @return la valeur de x
     */
    public double getX() {

        return x;
    }

    /**
     * Permet d'obtenir la coordonnées en y du point
     * @return la valeur de y
     */
    public double getY() {

        return y;
    }

    /**************************************************
     * 
     * LES MUTATEURS 
     *
     **************************************************/
    /**
     * Permet de modifier la coordonnées en x du point
     * @param x la nouvelle valeur de x
     */
    public void setX(double x) {

        this.x = x;
    }

    /**
     * Permet de modifier la coordonnées en y du point
     * @param y la nouvelle valeur de y
     */
    public void setY(double y) {

        this.y = y;
    }

    /***********************************************
     * 
     * LES COMPORTEMENTS
     * 
     ************************************************/
    /**
     * Calcul la distance entre le point actuel et un autre point
     * @param point à considérer
     * @return la racine carrée de la somme des différences en x et en y au carré
     *
     */
    public double distance (Point2D point){
        return Math.sqrt(Math.pow(point.x-x,2) + Math.pow(point.y-y,2));
    }

    /**
     * Calcul la pente de la droite formée par le point actuel et un autre point
     * @param point à considérer
     * @return la différence de y divisé par la différence des x
     *
     */
    public double pente (Point2D point){
        return (point.y-y) / (point.x-x);
    }

    /**
     * Calcul le point au centre entre le point actuel et un autre point
     * @param point à considérer
     * @return les différences en x,y divisé par 2
     *
     */
    public Point2D milieu (Point2D point){
        return new Point2D(Math.abs((x-point.x)/2),Math.abs((y-point.y)/2));
    }

    /**
     * Retourne le point actuel sous forme de la chaîne "(x,y)"
     */
    public String toString(){
        return "(" + x + "," + y + ")";
    }

    /**
     * Retourne vrai si le point actuel est égal à un autre point
     * @param point à considérer
     * @return vrai si tous les attributs sont égaux
     */
    public boolean equals(Point2D point){
        return point.x == x && point.y == y;
    }

    /**
     * Retourne une copie du point actuel
     */
    public Point2D clone(){        	   
        return new Point2D(x,y);
    }

    
}
