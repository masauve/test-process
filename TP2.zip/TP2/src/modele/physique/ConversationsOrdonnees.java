package modele.physique;

/**  
 * Classe
 * 
 * On retrouve les méthodes suivantes :
 * - inserer(Object element)
 * - retirer(Object element) 
 * - getElements()
 * 
 * @author Catherine Sauvé
 * @author Xuan Truc Doan
 * @version Hiver 2021
 */

import java.util.List;
import java.util.Comparator;


public class ConversationsOrdonnees {

    /*******************************
	 * 	Constantes
	 *******************************/
    // Taille minimale du tableau qui conserve les données
    private static final int TAILLE_MIN = 100;
    // Valeur négative retournée si l'élément cherché est absent 
    private static final int ELEMENT_ABSENT = -1;

    //Pour comparer deux objets
    private final List<Comparator<Object>> comparateur = null;

    //tableau 
    private static Object[] tab;

    // Le nombre d'éléments significatifs dans le tableau
    private int nbElements;

    // La position à considérer lors des opérations (insérer, supprimer, ...)
    private int positionCourante;

    /**
     * Constructeur par défaut
     */
    public ConversationsOrdonnees() {

        tab = new Object[TAILLE_MIN];
        nbElements = TAILLE_MIN;
    }

    /**
     * Constructeur par paramètres
     * 
     * @param tab
     * @param nbElements
     * @param positionCourante
     */
    public ConversationsOrdonnees(int nbElements, int positionCourante) {

        this.nbElements = nbElements;
        this.positionCourante = positionCourante;
    }

    /**************************************************
     * LES ACCESSEURS :
     * méthodes qui retournent la valeur d'un attribut 
     **************************************************/
    /**
     * Permet d'obtenir le nombre d'éléments actuel
     * 
     * @return
     */
    public int getNbElements() {
        return nbElements;
    }

    /**************************************************
     * LES MUTATEURS : 
     * méthodes qui modifient la valeur d'un attribut 
     **************************************************/
    /**
     * Modifie la position courante du début 
     */
    public void setPositionCouranteDebut() {

        positionCourante = 0;
    }

    /**
     * Modifie la postion courante de la fin
     */
    public void setPositionCouranteFin() {

        positionCourante = nbElements - 1;
    }

    /**
     * Décale l'ensemble des données d'un tableau d'une case vers la droite
     * 
     * @param tab Le tableau à décaler
     * @param debut Le premier indice à considérer
	 * @param fin Le dernier indice à considérer
     */
    private void decalerDroite(Object[] tab, int debut, int fin) {

        /*
		 * Stratégie : On commence à la fin du tableau pour ne pas perdre des 
         *             données. On déplace les données d'une case vers la droite
         *             en mettant les valeurs de début à fin dans les cases de 
         *             début + 1 à fin + 1 en parcourant le tableau.
		 */

        for (int i = fin; i >= debut; i--) {

            ConversationsOrdonnees.tab[i + 1] = ConversationsOrdonnees.tab[i];
        }
    }

    /**
     * Décale l'entièreté des données d'un tableau d'une case vers la gauche
     * 
     * @param tab Le tableau à décaler
     * @param debut Le premier indice à considérer
	 * @param fin Le dernier indice à considérer
     */
    private void decalerGauche(Object[] tab, int debut, int fin) {

        /*
		 * Stratégie : On déplace les données d'une case vers la gauche en 
         *             mettant les valeurs de début à fin dans les cases de 
         *             début - 1 à fin - 1 en parcourant le tableau.
		 */
        for (int i = debut; i <= fin; i++) {

            ConversationsOrdonnees.tab[i - 1] = ConversationsOrdonnees.tab[i];
        }
    }

    /**
     * Insère l’élément à sa position dans la liste. Toutes les cases sont 
     * décalées d'une case à droite.
     * @param element
     * @throws Exception
     */
    public void inserer(Object element) throws Exception {
        /**
         * Statégie : On décale les données de la position jusqu'au nombre d'éléments
         * d'une case vers la droite avant d'insérer l'élément et d'incrémenter
         * nbElements
         */
        if (nbElements == tab.length) {

            throw new Exception("Liste est vide impossible de supprimer");
        }
        if (nbElements != 0) //&& positionInvalide())
         {

            throw new Exception("La position" + positionCourante + "est invalide");
        }

        decalerDroite(tab, positionCourante, nbElements - 1);

        tab[positionCourante] = element;

        nbElements++;
    }


    /**
     * Retire un élément de la liste
     * 
     * @param element
     * @throws Exception
     */
    public void retirer(Object element) throws Exception {
        
        /**
         * Stratégie : On utilise la fouille binaire dans le tableau.
         */
        
        int indice = fouilleBinaire(ConversationsOrdonnees.tab, element);
    
        if (nbElements == tab.length) {

            throw new Exception("Liste est vide impossible de supprimer");
        }
        if (nbElements != 0 )//&& positionInvalide()
         {

            throw new Exception("La position" + positionCourante + "est invalide");
        }

        decalerGauche(tab, indice, nbElements - 1);

    } 

    /**
	 * Sert à retourner si une valeur est présente ou non dans le tableau.
	 * Si elle s'y trouve, la valeur retournée sera sa position dans le tableau.
	 *
	 * Autrement, une valeur négative (ELEMENT_ABSENT) est retournée.
	 *
	 * @param tab Tableau dans lequel sera effectué la fouille
	 * @param element La valeur cherchée
     * @throws Exception
	 * @return La position de la valeur trouvée ou un nombre négatif.
	 */
	public int fouilleBinaire(Object tab[], Object element) throws Exception {

		/**
         * Stratégie : On utilise la fouille binaire dans le tableau.
         */

		// Au debut, l'espace de recherche le tableau au complet.
		int debut = 1;
		int fin = tab.length;
		
        // Indice servant à la recherche.		
		int milieu = 0;

        boolean trouvee = false;
        
        // Vérification que la liste n'est pas vide
        if (nbElements == 0) {

            // Message d'erreur si la liste est vide
            throw new Exception("Liste est vide il n'y a rien à retirer");
        }

		// Tant que les indices ne se sont pas croisés.
		while (!trouvee && debut <= fin){

			// On trouve le milieu de l'espace de recherche.
			milieu = (debut + fin) / 2;

			// On conserve la moitie de droite ou de gauche de l'espace de
			// recherche en déplaçant les indice de début ou de fin.
            if (comparerObjets(tab[milieu],element) < 0) {
                fin = milieu - 1;
            }

            else if (comparerObjets(tab[milieu],element) > 0){
				debut = milieu + 1;
			}

			else {
				trouvee = true;
			}
		}

        /** 
         * On retourne ELEMENT_ABSENT si l'élément cherché est absent. Sinon 
         * on retourne sa position qui correspond à la variable milieu.
         */
		return (!trouvee) ? ELEMENT_ABSENT : milieu;
    }

    /**
     * Permet de comparer deux objets ensemble.
     * 
     * @param objet1
     * @param objet2
     * @return
     */
    public int comparerObjets(Object objet1, Object objet2) {
        for (Comparator<Object> c : comparateur) {
            int result = c.compare(objet1, objet2);
            if (result != 0) {
                return result;
            }
        }
        return 0;
    }
   
    /**
     * Retourne null ou l’élément à la position fournie
     * @param position
     * @return
     */
    public Object getElement(int position) {

        return tab[position];

    }

    
}
