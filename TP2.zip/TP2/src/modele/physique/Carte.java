package modele.physique;
/**
 * Classe...
 * 
 * On retrouve les méthodes suivantes :
 * - genererPositionAleatoire()
 * - ajusterPosition(Point2D position)
 * 
 * @author Catherine Sauvé
 * @author Xuan Truc Doan
 * @version Hiver 2021
 */
import java.util.Random;

public class Carte extends Point2D{

    /*******************************
	 * 	Constantes
	 *******************************/
    //Taille de la carte
    public static final Point2D TAILLE_CARTE = new Point2D(1920,1080);

    //instance de Random pour obtenir des nombres aléaoires.
    private static Random rand = new Random();

    //instance de position
    private static Point2D position = new Point2D();
  
    /**
     * Permet de générer des positions aléatoires dans la carte
     * 
     * @return Position initialisée aléatoirement dans la carte
     */
    public static Point2D genererPositionAleatoire() {
        
        /*
         * Stratégie : Utilise la classe Random de java pour générer une 
         * position aléatoire dans la carte.
         */

        position.setX(TAILLE_CARTE.getX() * rand.nextDouble());
        position.setY(TAILLE_CARTE.getY() * rand.nextDouble());

        return position;

    }

    /**
     * Méthode utilitaire pour ajuster une position dans la carte
     * 
     * @return Position ajustée
     */
    public static Point2D ajusterPosition( Point2D position) {
        
        /*
         * Stratégie : Si la position reçue en entrée est à l’extérieur de la 
         * carte, ses coordonnées X et/ou Y sont ajustées, par rapport à la 
         * logique du toroïde, pour la ramener dans la carte.
         */

        //Si le point dépasse la limite en x
        if(position.getX() > TAILLE_CARTE.getX()) {

            position.setX(0);
        }
        //Si le point dépasse la limite en y
        else if(position.getY() > TAILLE_CARTE.getY()) {

            position.setY(0);
        }

        return position;
    }
        
    
}
