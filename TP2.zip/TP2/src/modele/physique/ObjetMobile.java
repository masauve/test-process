package modele.physique;
/**  
 * Classe abstraite
 * 
 * On retrouve les méthodes suivantes :
 * - Point2D seDeplacer(double t)
 * 
 * 
 * @author Catherine Sauvé
 * @author Xuan Truc Doan
 * @version Hiver 2021
 */
import java.lang.Math;
import java.util.Random;

public abstract class ObjetMobile extends ObjetPhysique {

    private double direction;
    protected double vitesse;
    protected double deviationStandard;

    private Random rand = new Random();

    /**
     * Constructeur par défaut
     */
    public ObjetMobile() {

        // Appel du constructeur par défaut de la classe ObjectPhysique
        super();

        direction = 0;
        vitesse = 0;
        deviationStandard = 0;
    }

    /**
     * Constructeur par paramètres
     * 
     * @param position
     * @param vitesse
     * @param deviation
     */
    public ObjetMobile(Point2D position, double vitesse, double deviationStandard) {

        super(position);

        this.vitesse = vitesse;
        this.deviationStandard = deviationStandard;
    }

    public ObjetMobile(ObjetMobile objetMobile) {

        super(objetMobile);

        this.vitesse = objetMobile.vitesse;
        this.deviationStandard = objetMobile.deviationStandard;
    }

    /***********************************************
     * LES COMPORTEMENTS
     ************************************************/

    @Override
    /**
     * Permet d'obtenir une position
     * @return la position
     */
    public Point2D getPosition() {

        return position;
    }

    /**
     * Permet de se déplacer en modifiant la direction actuelle
     * 
     * @param t
     * @return
     */
    public Point2D seDeplacer(double t) {

        double nouvelleDirection = direction(t + 1);

        nouvelleDirection = direction(t) + rand.nextGaussian() * this.deviationStandard;

        position = getPosition();
        
        position.setX(t);
        position.setY(t);

        position.x += this.vitesse * Math.cos(nouvelleDirection);
        position.y += this.vitesse * Math.sin(nouvelleDirection);

        Carte.ajusterPosition(position);

        return position;
    }

    public double direction(double direction) {

        return this.direction / Math.PI * 180;
    }




}
