package modele.physique;
/**  
 * Classe abstraite
 * 
 * On retrouve les méthodes suivantes :
 * 
 * 
 * @author Catherine Sauvé
 * @author Xuan Truc Doan
 * @version Hiver 2021
 */
public abstract class ObjetPhysique {
    
    //On conserve une position
    protected Point2D position = new Point2D();

    /**
     * Constructeur par défaut
     */
    public ObjetPhysique() {
    }
    
    /**
     * Constructeur par paramètre
     * @param position
     */
    public ObjetPhysique(Point2D position) {

        this.position = position;

    } 

    public ObjetPhysique(ObjetPhysique objetPhysique) {

        this(objetPhysique.position);
    }

	/**************************************************
     * LES ACCESSEURS 
     **************************************************/
    /**
     * Permet d'obtenir une position
     * @return la position
     */
    public Point2D getPosition() {

        return position;
    }

}
